package progetto.mp.vannacci.serena.library.service.exporting.format.syntax;

public final class XmlSyntax {

	private XmlSyntax() {
	}

	public static final String OPEN_PREFIX = "<";
	public static final String CLOSE_PREFIX = "</";
	public static final String SUFFIX = ">";
	public static final String NEWLINE = "\n";
}
