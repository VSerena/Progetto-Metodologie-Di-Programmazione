package progetto.mp.vannacci.serena.library.service.exporting.format.syntax;

public final class JsonSyntax {

	private JsonSyntax() {
	}

	public static final String OPEN_BRACE = "{";
	public static final String CLOSE_BRACE = "}";
	public static final String ARRAY_OPEN = "[";
	public static final String ARRAY_CLOSE = "]";
	public static final String KEY_VALUE_SEPARATOR = ": ";
	public static final String COMMA = ",";
	public static final String QUOTE = "\"";
}