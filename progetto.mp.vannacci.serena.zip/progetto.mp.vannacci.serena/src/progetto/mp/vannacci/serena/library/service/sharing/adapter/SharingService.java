package progetto.mp.vannacci.serena.library.service.sharing.adapter;

import progetto.mp.vannacci.serena.library.model.LibraryComponent;

public interface SharingService {

	public String send(LibraryComponent component, String content);
}
